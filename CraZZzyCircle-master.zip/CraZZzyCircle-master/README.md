# CraZZzyCircle
Original idea is not mine. I just made it again to practice.
Inspired by a game named Crazy Circle on play store.

**Commands***
Press enter if rotating bar is at same colored arc.
